"""Synthetic unit PDDL only: actual inventory.build grouping and fail-closed paths."""
import json,tempfile,time,shutil,unittest
from pathlib import Path
from unittest.mock import patch
import inventory
ROOT=inventory.ROOT;START=time.monotonic();TMP=Path(tempfile.mkdtemp(prefix='flaxC-fixture-',dir='/tmp'));EVIDENCE={}
def problem(identity):
    return f'(define (problem a) (:domain mazenamo) (:objects r - robot p{identity} q{identity} - pos) (:init (rat r p{identity}) (handempty)) (:goal (and (rat r q{identity}) (handempty))))'
class Tests(unittest.TestCase):
    def setUp(self):
        self.checkout=TMP/'checkout';self.checkout.mkdir(exist_ok=False);self.base=self.checkout/'pddl_files/problems/mazenamo_problems';self.base.mkdir(parents=True);self.domain=self.checkout/'domain.pddl';self.domain.write_bytes(inventory.DOMAIN.read_bytes())
        for s in inventory.STRATA:
            directory=self.base/f'pddl_{s}';directory.mkdir()
            for i in range(5):(directory/f'mazenamo_problem_{i}.pddl').write_text(problem(s.replace('_','')+str(i)))
        train=self.base/'pddl_10x10_train';train.mkdir();self.train=train/'mazenamo_problem_300.pddl';self.train.write_text(problem('train'))
        self.overlap=self.base/'pddl_15x15_expert/mazenamo_problem_1.pddl';self.overlap.write_text(self.train.read_text())
        self.forced=self.base/'pddl_15x15_expert/mazenamo_problem_0.pddl';self.variant=self.forced.parent/'zz_variant.pddl';self.variant.write_text('; comment\n'+self.forced.read_text().replace('(problem a)','(problem different_title)'))
        record={'path':str(self.train.relative_to(self.checkout)),'sha256':inventory.sha(self.train),'index':0};self.labels={'ordered_instances':[record]*195,'validation':[record]*19,'training':[record]*176}
        self.history=[{'instance':{'path':str(self.forced.relative_to(self.checkout)),'sha256':inventory.sha(self.forced)},'stage_b_purpose':['planning/VAL execution-path coverage']}]
        real=Path.read_text
        def read(p,*a,**kw):
            if p==inventory.A/'artifacts/full/successful-labels.json':return json.dumps(self.labels)
            if p==inventory.B/'evidence/exposure-ledger.json':return json.dumps(self.history)
            return real(p,*a,**kw)
        self.patches=[patch.object(inventory,'CHECKOUT',self.checkout),patch.object(inventory,'DOMAIN',self.domain),patch.object(Path,'read_text',read)]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        shutil.rmtree(self.checkout)
    def test_variants_group_split_and_training_overlap(self):
        r=inventory.build();groups=[g for g in r['duplicates'] if len(g['members'])>1];self.assertEqual(len(groups),1);g=groups[0];self.assertEqual(len(g['members']),2);self.assertTrue(g['forced_development'])
        self.assertIn(g['group_id'],{x['group_id'] for x in r['development']});self.assertNotIn(g['group_id'],{x['group_id'] for x in r['evaluation']+r['unused']})
        overlap=next(x for x in r['inventory'] if x['path']==str(self.overlap.relative_to(self.checkout)));self.assertNotIn(overlap['group_id'],{x['group_id'] for x in r['development']+r['evaluation']+r['unused']})
        self.assertEqual(g['representative']['path'],min(x['path'] for x in g['members']));self.assertEqual(r,inventory.build(reverse=True))
        EVIDENCE['actual_build']={'two_presentation_variants_one_group':True,'forced_member_forces_whole_group_development':True,'training_overlap_excluded_from_all_evaluation_allocation':True,'representative_fixed_path_order':True,'reverse_traversal_identical':True}
    def test_conflict_hash_missing_and_unsupported(self):
        conflict=self.base/'pddl_12x12_expert/conflict.pddl';conflict.write_text(self.variant.read_text())
        with self.assertRaisesRegex(ValueError,'Conflicting duplicate stratum'):inventory.build()
        conflict.unlink();self.forced.write_text(self.forced.read_text()+'\n; changed raw bytes')
        with self.assertRaisesRegex(ValueError,'Exposed source hash mismatch'):inventory.build()
        self.train.unlink()
        with self.assertRaises(FileNotFoundError):inventory.build()
        self.train.write_text(problem('train'));self.forced.write_text(self.variant.read_text().replace('(problem different_title)','(problem a)').removeprefix('; comment\n'));bad=self.base/'pddl_12x12_easy/unsupported.pddl';bad.write_text(problem('unsupported').replace('(:init','(:metric minimize (total-cost)) (:init'))
        with self.assertRaisesRegex(ValueError,'Unsupported problem sections'):inventory.build()
        EVIDENCE['fail_closed']={'conflicting_strata_block_allocation':True,'wrong_exposed_hash':True,'missing_training_source':True,'unsupported_constructs':True}
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));EVIDENCE.update(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,seconds=time.monotonic()-START,fixture_only=True,no_released_problems_or_cache_modified=True)
    (ROOT/'evidence/grouping-fixture-tests.json').write_text(json.dumps(EVIDENCE,indent=2)+'\n');shutil.rmtree(TMP);raise SystemExit(0 if result.wasSuccessful() else 1)
