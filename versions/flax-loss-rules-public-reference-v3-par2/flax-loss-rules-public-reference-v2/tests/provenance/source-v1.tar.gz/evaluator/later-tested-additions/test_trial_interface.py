"""Negative input fixtures only; no training, teacher, or evaluation case is run."""
import json,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from inventory import ROOT
from trial_interface import run
START=time.monotonic();results=[]
class Tests(unittest.TestCase):
    def test_manifest_failure_normalized_without_training(self):
        with patch('trial_interface.train') as train:
            r=run('run_candidate_trial','invalid-manifest-fixture',ROOT/'candidates/missing/manifest.json')
            train.assert_not_called();self.assertEqual(r,{'status':'candidate_invalid','primary_score':None})
        f=json.loads((ROOT/'runs/invalid-manifest-fixture.interface-feedback.json').read_text());self.assertEqual(f['status'],'candidate_invalid');self.assertIsNone(f['primary_score']);self.assertNotIn('Traceback',json.dumps(f));self.assertNotIn(str(ROOT),json.dumps(f));results.append('missing manifest: candidate_invalid/null, no training, sanitized')
    def test_incompatible_artifact_without_evaluation(self):
        from scorer import torch
        path=ROOT/'runs/incompatible-fixture.pt';torch.save({'wrong_key':torch.tensor([1.])},path)
        with patch('trial_interface.guarded_evaluation') as evaluate:
            r=run('evaluate_fixed','invalid-artifact-fixture',checkpoint=path);evaluate.assert_not_called();self.assertEqual(r,{'status':'candidate_invalid','primary_score':None})
        results.append('incompatible tensor artifact: candidate_invalid/null, no cases')
    def test_task_asset_failure_infrastructure(self):
        with patch('trial_interface.verify_protected',side_effect=ValueError('broken task asset')):
            r=run('run_candidate_trial','infrastructure-fixture',ROOT/'candidates/reference/manifest.json');self.assertEqual(r,{'status':'infrastructure_unscored','primary_score':None})
        results.append('task asset failure: infrastructure_unscored/null')
    def test_output_collision(self):
        p=ROOT/'runs/collision-fixture.interface-record.json';p.write_bytes(b'preserved')
        with self.assertRaises(FileExistsError):run('run_candidate_trial','collision-fixture',ROOT/'candidates/reference/manifest.json')
        self.assertEqual(p.read_bytes(),b'preserved');results.append('existing output untouched')
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));(ROOT/'evidence/trial-interface-tests.json').write_text(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'seconds':time.monotonic()-START,'fixtures':results,'no_training_or_cases_run':True},indent=2)+'\n');raise SystemExit(0 if result.wasSuccessful() else 1)
