"""Normalized unscored-input interface around the frozen Stage C implementation.
No candidate code is imported here; candidate training stays in its own process.
"""
import argparse,json,re,time
from pathlib import Path
from inventory import ROOT,sha
from contract import verify_protected,candidate_manifest
from metrics import feedback
from cli import train,guarded_evaluation,trial

def write_new(path,obj):
    with Path(path).open('x') as f:f.write(json.dumps(obj,indent=2)+'\n')
def artifact_valid(path):
    from scorer import torch,fixed_model,validate_tensors
    validate_tensors(torch.load(path,map_location='cpu',weights_only=True),fixed_model())
def run(command,run_id,candidate=None,checkpoint=None):
    if not re.fullmatch('[A-Za-z0-9_-]+',run_id):raise ValueError('Unsafe run ID')
    started=time.monotonic();record=ROOT/'runs'/f'{run_id}.interface-record.json';response=ROOT/'runs'/f'{run_id}.interface-feedback.json'
    if record.exists() or response.exists() or (ROOT/'runs'/run_id).exists():raise FileExistsError('Output collision')
    status='infrastructure_unscored';result={'status':status,'primary_score':None};error=None;stage='assets'
    try:
        protocol=verify_protected()
        stage='candidate_manifest'
        if command=='run_candidate_trial':
            c=candidate_manifest(candidate);stage='candidate_training';checkpoint=train(candidate,run_id);stage='candidate_artifact';artifact_valid(checkpoint)
            stage='evaluation';roster=json.loads((ROOT/'manifests/evaluation.json').read_text());overall=3600+300+sum((20 if r['stratum'].startswith('12') else 40)+65 for r in roster)
            result=guarded_evaluation(checkpoint,ROOT/'runs'/f'{run_id}-evaluation',run_id,c['candidate_id'],remaining_guard=overall-(time.monotonic()-started))
        elif command=='evaluate_fixed':
            stage='candidate_artifact';artifact_valid(checkpoint);stage='evaluation';result=guarded_evaluation(checkpoint,ROOT/'runs'/f'{run_id}-evaluation',run_id,'supplied-checkpoint')
        else:
            stage='reference_trial';trial(ROOT/'candidates/reference/manifest.json',run_id,True);result=json.loads((ROOT/'runs'/f'{run_id}-evaluation/result.json').read_text())
        status=result['status']
    except Exception as exc:
        error=repr(exc);status='candidate_invalid' if stage in {'candidate_manifest','candidate_artifact','candidate_training'} else 'infrastructure_unscored';result={'status':status,'primary_score':None}
    resources={'interface_wall_seconds':time.monotonic()-started}
    write_new(record,{'run_id':run_id,'command':command,'status':status,'primary_score':result.get('primary_score'),'stage':stage,'error':error,'adapter_sha256':sha(ROOT/'trial_interface.py'),'protocol_sha256':sha(ROOT/'protocol.json'),'resources':resources,'scope':'Input/status serialization adapter added during the reference run; frozen evaluator/trainer unmodified.'})
    write_new(response,feedback(result,resources));return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['run_reference_trial','run_candidate_trial','evaluate_fixed']);p.add_argument('--run-id',required=True);p.add_argument('--candidate',type=Path);p.add_argument('--checkpoint',type=Path);args=p.parse_args()
    if args.candidate is not None and not args.candidate.is_absolute():args.candidate=ROOT/args.candidate
    result=run(args.command,args.run_id,args.candidate,args.checkpoint);print(json.dumps({'status':result['status'],'primary_score':result['primary_score']}));raise SystemExit(0 if result['status']=='complete' else 1)
