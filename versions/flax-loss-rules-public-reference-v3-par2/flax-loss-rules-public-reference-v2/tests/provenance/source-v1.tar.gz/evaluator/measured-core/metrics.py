"""Independent complete-record aggregation; no candidate metrics accepted."""
import math,statistics
from inventory import STRATA,PROTOCOL,ROOT,sha
ORDINARY={'valid','no_plan','invalid_plan','deadline'}
def utility(outcome,elapsed,deadline,validity):
    if not math.isfinite(elapsed) or elapsed<0 or deadline<=0:raise ValueError('Invalid timing')
    if outcome=='valid' and validity is True and elapsed<=deadline:return 1-elapsed/(10*deadline)
    if outcome in ORDINARY:return 0.
    return None
def aggregate(roster,records):
    result={'status':'infrastructure_unscored','primary_score':None}
    expected={r['group_id']:r for r in roster}
    if len(expected)!=len(roster) or len(records)!=len(roster):return dict(result,diagnostic='incomplete_or_duplicate_workload')
    identity=None
    seen=set();buckets={s:[] for s in STRATA}
    for r in records:
        gid=r.get('instance_id')
        if gid not in expected or gid in seen:return dict(result,diagnostic='unexpected_or_duplicate_record')
        seen.add(gid);e=expected[gid]
        current=tuple(r.get(k) for k in ['run_id','candidate_id','checkpoint_sha256'])
        if any(v is None for v in current) or r.get('seed')!=0 or (identity is not None and current!=identity):return dict(result,diagnostic='trial_identity_mismatch')
        identity=current
        if (ROOT/'protocol.json').exists() and r.get('protocol_sha256')!=sha(ROOT/'protocol.json'):return dict(result,diagnostic='protocol_digest_mismatch')
        if r.get('protocol_id')!=PROTOCOL or r.get('stratum')!=e['stratum'] or r.get('instance_sha256')!=e['sha256'] or r.get('deadline')!=(20. if e['stratum'].startswith('12') else 40.):return dict(result,diagnostic='identity_or_policy_mismatch')
        if r['outcome'] not in ORDINARY:return dict(result,diagnostic='unscored_case')
        try:u=utility(r['outcome'],r['elapsed'],r['deadline'],r['original_plan_validity'])
        except (ValueError,TypeError,KeyError):return dict(result,diagnostic='invalid_timing_record')
        if r['outcome']=='valid' and (r['elapsed']>r['deadline'] or r['original_plan_validity'] is not True):return dict(result,diagnostic='invalid_success_claim')
        if r.get('utility')!=u:return dict(result,diagnostic='utility_mismatch')
        buckets[r['stratum']].append(r)
    if any(not b for b in buckets.values()):return dict(result,diagnostic='empty_primary_stratum')
    summaries={}
    for s,b in buckets.items():
        successful=[r for r in b if r['outcome']=='valid'];failed=[r['deadline'] if r['outcome']!='valid' else r['elapsed'] for r in b]
        summaries[s]={'count':len(b),'successes':len(successful),'success_rate':len(successful)/len(b),'mean_utility':statistics.mean(r['utility'] for r in b),'successful_mean_seconds':statistics.mean(r['elapsed'] for r in successful) if successful else None,'successful_mean_plan_length':statistics.mean(r['plan_length'] for r in successful) if successful else None,'failure_penalized_mean_seconds':statistics.mean(failed),'outcome_counts':{o:sum(r['outcome']==o for r in b) for o in sorted(ORDINARY)}}
    return {'status':'complete','primary_score':100*statistics.mean(s['mean_utility'] for s in summaries.values()),'macro_success_rate':statistics.mean(s['success_rate'] for s in summaries.values()),'micro_success_rate':sum(r['outcome']=='valid' for r in records)/len(records),'strata':summaries,'failure_penalized_timing_definition':'elapsed for valid cases; stratum deadline for each ordinary failure','count':len(records)}
def feedback(result,resources):
    permitted={'count','successes','success_rate','successful_mean_seconds','successful_mean_plan_length','failure_penalized_mean_seconds'}
    return {'status':result['status'],'primary_score':result['primary_score'],'strata':{s:{k:v for k,v in row.items() if k in permitted} for s,row in result.get('strata',{}).items()},'diagnostics':[] if result['status']=='complete' else ['Evaluation did not complete authoritatively.'],'resources':resources}
