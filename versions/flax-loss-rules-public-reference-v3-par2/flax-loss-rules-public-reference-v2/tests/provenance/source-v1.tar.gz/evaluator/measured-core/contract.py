"""Task-owned immutable protocol and candidate-manifest checks (not a sandbox)."""
import json,re
from pathlib import Path
from inventory import ROOT,CHECKOUT,PROTOCOL,sha
CACHE=ROOT/'data/training_data_Mazenamo.pkl'
CACHE_SHA='6622009ab767a0d2db5d40a5e6efa577820569ed88a7dca804ac0d4c09db7a8c'
def candidate_manifest(path):
    p=Path(path).resolve(); allowed=(ROOT/'candidates').resolve()
    if not p.is_relative_to(allowed):raise ValueError('Manifest outside allowed candidate directory')
    c=json.loads(p.read_text());fields={'candidate_id','loss_path','loss_sha256','abi_version','description'}
    if set(c)!=fields or c['abi_version']!='compute_loss-v1' or not re.fullmatch('[A-Za-z0-9_-]+',c['candidate_id']):raise ValueError('Invalid manifest fields/ABI/ID')
    loss=Path(c['loss_path'])
    if loss.is_absolute() or '..' in loss.parts:raise ValueError('Unsafe loss path')
    loss=(p.parent/loss).resolve()
    if not loss.is_relative_to(p.parent) or not loss.is_file() or sha(loss)!=c['loss_sha256']:raise ValueError('Missing/escaping/mismatched loss')
    return dict(c,resolved_loss=str(loss))
def reference_candidate(path):
    c=candidate_manifest(path)
    if c['candidate_id']!='reference-bce' or c['loss_sha256']!=sha(CHECKOUT/'guidance/reference_loss.py'):raise ValueError('Reference treatment mismatch')
    return c
def verify_protected():
    definition=json.loads((ROOT/'protected-assets.json').read_text())
    for r in definition['files']:
        p=ROOT/r['path']
        if not p.is_file() or sha(p)!=r['sha256']:raise ValueError('Protected task asset changed: '+r['path'])
    if sha(CACHE)!=CACHE_SHA:raise ValueError('Frozen cache mismatch')
    for r in definition['external']:
        if sha(Path(r['path']))!=r['sha256']:raise ValueError('External asset changed')
    for r in definition['links']:
        p=ROOT/r['path']
        if not p.is_symlink() or str(p.resolve())!=r['target']:raise ValueError('Protected symlink changed')
    return json.loads((ROOT/'protocol.json').read_text())
