"""Fixed Stage C trainer: fresh callback training only, no scientific changes."""
import argparse, resource, shutil, time, traceback
from common import *
from torch.utils.data import DataLoader
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate',type=Path,required=True)
parser.add_argument('--run-id',required=True)
args=parser.parse_args()
started=time.perf_counter()
# Verify before reserving outputs or initializing a model; no collection fallback.
checked_cache()
from contract import verify_protected, candidate_manifest
verify_protected()
candidate=candidate_manifest(args.candidate)
import importlib.util
spec=importlib.util.spec_from_file_location('candidate_loss',candidate['resolved_loss'])
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
loss_callback=module.compute_loss
out=reserve(ROOT/'runs'/args.run_id)
for n in ['model','checkpoints']: reserve(out/n)
g=guider(loss_callback,out/'model')
train,val=graphs(g)
labels=json.loads((A/'artifacts/full/successful-labels.json').read_text())
expected={phase:[tensor_digest(graph_batch_collate([ds[i] for i in range(j,min(j+16,len(ds)))])['graph_input']) for j in range(0,len(ds),16)] for phase,ds in [('train',train),('val',val)]}
manifest=dict(arm='callback',candidate=candidate,run_id=args.run_id,provenance=provenance(),data_sha256=sha(CACHE),
             ordering_and_split=labels,feature_schema=schema(g),
             configuration=json.loads((A/'artifacts/full/configuration.json').read_text()),
             load_dataset_from_file=True,load_from_file=False,trained_model_reuse=False,seed=0,
             output=str(out),temp=str(TMP),validation_forward_passes_expected=62,
             upstream_loss_source_sha256=sha(A/'flax/gnn/gnn_utils.py'))
manifest['runner_source_hashes']={p.name:sha(p) for p in [ROOT/'common.py',ROOT/'train.py',ROOT/'execute.sh']}
manifest['training_only']=True
dump(out/'manifest.json',manifest)
counts={'train':0,'val':0}; exposure=0; callback_calls=0
def counted(logits,targets,graph,*,epoch,step):
    global callback_calls
    callback_calls+=1
    return loss_callback(logits,targets,graph,epoch=epoch,step=step)
g._compute_loss=counted
trace=(out/'loss-trace.jsonl').open('x')
def observer(phase,epoch,step,inputs,targets,output,loss,model,optimizer):
    global exposure
    batch=counts[phase]%(11 if phase=='train' else 2)
    actual=tensor_digest(inputs); assert actual==expected[phase][batch],(phase,epoch,batch)
    identities=labels['training' if phase=='train' else 'validation'][batch*16:(batch+1)*16]
    if phase=='train': exposure+=len(identities)
    row={'phase':phase,'epoch':epoch,'step':step,'batch':batch,'loss':loss.detach().item(),
         'instance_indices':[r['index'] for r in identities],'input_digest':actual,
         'logits_digest':tensor_digest({'nodes':output['nodes']}),'n_node':inputs['n_node'].tolist(),
         'parameters_digest':tensor_digest(model.state_dict())}
    if phase=='train': row['gradients_digest']=tensor_digest({k:p.grad for k,p in model.named_parameters()})
    trace.write(json.dumps(row)+'\n'); trace.flush(); counts[phase]+=1
original=gnn_utils.train_model
import guidance.gnn_guidance as guidance_module
def observed_train(model,*a,**kw):
    global training_start,training_seconds
    torch.save({k:v.detach().clone() for k,v in model.state_dict().items()},out/'initial.pt')
    torch.save(torch.get_rng_state().clone(),out/'initial-torch-rng.pt')
    kw.update(save_folder=str(out/'checkpoints'),batch_observer=observer)
    training_start=time.perf_counter(); result=original(model,*a,**kw)
    training_seconds=time.perf_counter()-training_start
    return result
guidance_module.train_model=observed_train
try:
    g.seed(0); g.train('Mazenamo')
    trace.close()
    final=torch.load(out/'model/final_seed0_Mazenamo.pt',map_location='cpu',weights_only=True)
    last=torch.load(out/'checkpoints/model300.pt',map_location='cpu',weights_only=True)
    assert comparison(final,last)['tensor_equal']
    assert counts=={'train':3311,'val':62} and exposure==52976
    assert callback_calls==(3373)
    dump(out/'scorer-metadata.json',{'feature_schema':schema(g),'num_steps':3,'layer_size':16,'dropout':0.,'node_input_dim':23,'edge_input_dim':24,'node_output_dim':1,'globals':False,'final_model_sha256':sha(out/'model/final_seed0_Mazenamo.pt')})
    dump(out/'result.json',dict(status='PASS',counts=counts,training_graph_exposures=exposure,
         callback_calls=callback_calls,final_vs_epoch300=comparison(final,last),
         training_seconds=training_seconds,training_preparation_seconds=training_start-started,post_training_serialization_and_checks_seconds=time.perf_counter()-training_start-training_seconds,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,total_seconds=time.perf_counter()-started,exit_status=0))
except BaseException as exc:
    dump(out/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc(),counts=counts,
         elapsed_seconds=time.perf_counter()-started)); raise
finally:
    trace.close(); shutil.rmtree(TMP)
