"""Fixed schema/architecture tensor loader; candidate loss modules never imported."""
from common import *
from pddlgym.parser import PDDLDomainParser,PDDLProblemParser
from pddlgym.structs import State

def parse_problem(path):
    domain=PDDLDomainParser(str(CHECKOUT/'pddl_files/domains/mazenamo.pddl'),expect_action_preds=False,operators_as_actions=True)
    problem=PDDLProblemParser(str(path),domain.domain_name,domain.types,domain.predicates,list(domain.actions),domain.constants)
    goal=problem.goal
    if type(goal).__name__=='Literal':goal=LiteralConjunction([goal])
    return domain,State(frozenset(problem.initial_state),frozenset(problem.objects),goal)
def fixed_model():
    # Dimension-only task-owned template; no case graph construction or forward pass.
    graph={'nodes':np.zeros((1,23)), 'edges':np.zeros((1,24)), 'globals':None,'n_node':np.array([1]),'n_edge':np.array([1]),'senders':np.array([0]),'receivers':np.array([0])}
    target=dict(graph,nodes=np.zeros((1,1)))
    return setup_graph_net(GraphDictDataset([graph],[target]),use_gpu=False,num_steps=3)
def validate_tensors(state,model):
    expected=model.state_dict()
    if not isinstance(state,dict) or state.keys()!=expected.keys():raise ValueError('Checkpoint key mismatch')
    for k,v in state.items():
        if not isinstance(v,torch.Tensor) or v.shape!=expected[k].shape or v.dtype!=expected[k].dtype or not torch.isfinite(v).all():raise ValueError('Incompatible/non-finite checkpoint tensor: '+k)
def load_scorer(checkpoint,domain):
    state=torch.load(checkpoint,map_location='cpu',weights_only=True);model=fixed_model();validate_tensors(state,model);model.load_state_dict(state)
    s=json.loads((ROOT/'feature-schema.json').read_text());g=guider()
    def resolve(name):
        if name.startswith('WANT'):return g.wrap_goal_literal(resolve(name[4:]))
        if name.startswith('REV'):return g.reverse_binary_literal(resolve(name[3:]))
        return domain.types[name] if name in domain.types else domain.predicates[name]
    g._node_feature_to_index={resolve(k):v for k,v in s['node_features'].items()}
    g._edge_feature_to_index={resolve(k):v for k,v in s['edge_features'].items()}
    g._num_node_features=23;g._num_edge_features=24;g._model=model
    if schema(g)!=s:raise ValueError('Feature schema mismatch')
    return g
