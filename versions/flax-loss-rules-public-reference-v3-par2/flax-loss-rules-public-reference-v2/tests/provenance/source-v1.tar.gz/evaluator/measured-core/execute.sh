#!/usr/bin/env bash
set -euo pipefail
stage_c_root=$(cd -- "$(dirname -- "$0")" && pwd)
stage_b_python="$stage_c_root/../stage_a_20261004/venv/bin/python"
cd "$stage_c_root/flax"
export PYTHONPATH="$stage_c_root/flax:$stage_c_root/flax/src" PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PATH="$(dirname "$stage_b_python"):$PATH"
exec taskset -c 0-3 "$stage_b_python" -u "$stage_c_root/$@"
