"""Authoritative external-clock, original-PDDL VAL evaluator; no candidate imports."""
import json,os,re,resource,select,socket,subprocess,tempfile,time
from pathlib import Path
from inventory import ROOT,CHECKOUT,DOMAIN,PROTOCOL,sha
from supervision import cleanup,register_session
from metrics import utility,aggregate,feedback
PYTHON=ROOT.parent/'stage_a_20261004/venv/bin/python'
VAL=CHECKOUT/'VAL/build/linux64/Release/bin/Validate'
def clean_env():
    env=dict(os.environ,PYTHONHASHSEED='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=f'{CHECKOUT}:{CHECKOUT}/src:{ROOT}')
    env['PATH']=str(PYTHON.parent)+':'+os.environ['PATH'];return env
def receive(sock,seconds):
    end=time.monotonic()+max(0,seconds);data=b''
    while time.monotonic()<end:
        ready,_,_=select.select([sock],[],[],max(0,end-time.monotonic()))
        if not ready:return None
        chunk=sock.recv(65536)
        if not chunk:raise RuntimeError('Worker IPC closed before result')
        data+=chunk
        if b'\n' in data:return json.loads(data.split(b'\n',1)[0])
    return None
def classify_failure(message):
    # Locked FD driver exit-code meanings: 10/11 unsolvable,12 incomplete;
    # 20..24 memory/time exhaustion; GNU timeout124 expected search cutoff.
    search=[r for r in message.get('statuses',[]) if 'fast-downward.py' in r['command'] and '--cleanup' not in r['command']]
    if message.get('exception') not in ('PlanningFailure','PlanningTimeout') or not search:return 'infrastructure'
    if any(r['exit_status'] not in {0,1,2,3,10,11,12,20,21,22,23,24,124} for r in search):return 'infrastructure'
    if message['exception']=='PlanningTimeout' or any(r['exit_status'] in {10,11,12,20,21,22,23,24,124} for r in search):return 'no_plan'
    return 'infrastructure' # success exit + unparsable plan is ambiguous, never a convenient zero.
def validation_outcome(status,text):
    if status==0 and 'Plan valid' in text:return 'valid'
    if status in {0,1} and ('Plan failed' in text or 'Goal not satisfied' in text or 'Plan invalid' in text or 'Bad plan' in text):return 'invalid_plan'
    return 'infrastructure'
def case_evaluate(case,checkpoint,out,run_id,candidate_id):
    out=Path(out);out.mkdir(exist_ok=False);start=time.monotonic();deadline=20. if case['stratum'].startswith('12') else 40.
    original=CHECKOUT/case['path']
    if not original.is_file() or sha(original)!=case['sha256']:raise ValueError('Case asset mismatch')
    temporary=Path(tempfile.mkdtemp(prefix='flaxC-',dir='/tmp'));work=temporary/'checkout';work.mkdir();(work/'stage-c-case-root').touch()
    (work/'VAL').symlink_to(CHECKOUT/'VAL',target_is_directory=True);(work/'config').symlink_to(CHECKOUT/'config',target_is_directory=True)
    temp=temporary/'tmp';temp.mkdir();env=clean_env();env['TMPDIR']=str(temp);env['FLAXC_TMP_DIR']=str(temp)
    parent,child=socket.socketpair();log=(out/'worker.log').open('xb');p=subprocess.Popen([str(PYTHON),'-u',str(ROOT/'worker.py'),'--fd',str(child.fileno()),'--checkpoint',str(checkpoint),'--case',str(original),'--audit',str(out),'--deadline',str(deadline)],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,pass_fds=(child.fileno(),));child.close();register_session(p.pid);sids=[p.pid];validator=None;t0=None;end=None;message=None;receipt=None;validity=None;validation_status=None;plan_length=None;outcome='infrastructure';error=None
    try:
        ready=receive(parent,60.);ready_time=time.monotonic()
        if not ready or ready.get('kind')!='READY':raise RuntimeError('Worker did not reach READY')
        (out/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
        t0=time.monotonic();parent.sendall(b'GO\n');cutoff=t0+deadline
        message=receive(parent,cutoff-time.monotonic());receipt=time.monotonic()
        if message is None or receipt>cutoff:outcome='deadline'
        elif message.get('kind')!='RESULT':raise RuntimeError('Worker failed during active planning')
        elif message.get('plan') is None:outcome=classify_failure(message)
        else:
            plan=message['plan']
            if not isinstance(plan,list) or not all(isinstance(a,str) and re.fullmatch(r'\([a-zA-Z0-9_\-\s]+\)',a) for a in plan):raise RuntimeError('Malformed returned plan')
            plan_path=out/'plan.plan';plan_path.write_text('\n'.join(f'{i}: {a}' for i,a in enumerate(plan))+'\n');plan_length=len(plan)
            with (out/'final-validation.log').open('xb') as vout:
                validator=subprocess.Popen([str(VAL),'-v',str(DOMAIN),str(original),str(plan_path)],cwd=work,env=env,stdout=vout,stderr=subprocess.STDOUT,start_new_session=True);sids.append(validator.pid);register_session(validator.pid)
                try:validator.wait(timeout=max(0,cutoff-time.monotonic()))
                except subprocess.TimeoutExpired:outcome='deadline'
                else:
                    validation_status=validator.returncode;text=(out/'final-validation.log').read_text(errors='replace');outcome=validation_outcome(validation_status,text);validity=True if outcome=='valid' else False if outcome=='invalid_plan' else None
            end=time.monotonic()
            if end>cutoff:outcome='deadline';validity=None
        end=time.monotonic() if end is None else end
    except BaseException as exc:error=repr(exc);end=time.monotonic()
    finally:
        if t0 is None:ready_time=time.monotonic()
        cleaned=cleanup(sids,5.);p.wait();
        if validator is not None:validator.wait()
        parent.close();log.close()
        if cleaned['ok']:
            for sid in sids:register_session(sid,False)
    if not cleaned['ok']:outcome='infrastructure';error='Process cleanup failed'
    if t0 is not None and end>t0+deadline and outcome!='infrastructure':outcome='deadline';validity=None
    retained_statuses=message.get('statuses',[]) if message else []
    if not retained_statuses and (out/'subprocesses.jsonl').exists():retained_statuses=[json.loads(line) for line in (out/'subprocesses.jsonl').read_text().splitlines()]
    for launch in sorted(out.glob('subprocess-*.launch.json')):
        launched=json.loads(launch.read_text())
        if not any(row['command']==launched['command'] and row.get('id')==launched['id'] for row in retained_statuses):retained_statuses.append(dict(launched,exit_status=None,termination='supervisor cutoff/cleanup; underlying wait status not observed'))
    elapsed=(end-t0) if t0 is not None else 0.
    row={'protocol_id':PROTOCOL,'protocol_sha256':sha(ROOT/'protocol.json') if (ROOT/'protocol.json').exists() else None,'run_id':run_id,'candidate_id':candidate_id,'checkpoint_sha256':sha(checkpoint),'seed':0,'stratum':case['stratum'],'instance_id':case['group_id'],'instance_sha256':case['sha256'],'outcome':outcome,'original_plan_validity':validity,'deadline':deadline,'elapsed':elapsed,'t0_monotonic':t0,'result_end_monotonic':end,'plan_receipt_monotonic':receipt,'validation_complete_monotonic':end if validation_status is not None else None,'startup_seconds':ready_time-start,'cleanup_seconds':cleaned['seconds'],'case_wall_seconds':time.monotonic()-start,'deadline_overshoot_seconds':max(0,elapsed-deadline) if outcome=='deadline' else 0.,'worker_exit_status':p.returncode,'validator_exit_status':validator.returncode if validator is not None else None,'underlying_exit_statuses':retained_statuses,'plan_length':plan_length,'utility':utility(outcome,elapsed,deadline,validity),'cleanup':cleaned,'error':error,'temporary_directory':str(temporary),'exposure':case['exposure']}
    (out/'record.json').write_text(json.dumps(row,indent=2)+'\n')
    # Retain temporary planner inputs outside scored interval. No previous-stage writes.
    import shutil
    shutil.copytree(temp,out/'temporary-artifacts');shutil.rmtree(temporary)
    row['audit_copy_seconds']=time.monotonic()-start-row['case_wall_seconds'];(out/'record.json').write_text(json.dumps(row,indent=2)+'\n');return row

def evaluate(roster,checkpoint,out,run_id,candidate_id):
    from contract import verify_protected
    verify_protected()
    from scorer import torch,fixed_model,validate_tensors
    validate_tensors(torch.load(checkpoint,map_location='cpu',weights_only=True),fixed_model())
    out=Path(out);out.mkdir(exist_ok=False);(out/'audit').mkdir();start=time.monotonic();guard=300+sum((20 if c['stratum'].startswith('12') else 40)+60+5 for c in roster);records=[]
    stream=(out/'records.jsonl').open('x')
    for i,case in enumerate(roster):
        if time.monotonic()-start>guard:break
        row=case_evaluate(case,checkpoint,out/'audit'/f'{i:04d}',run_id,candidate_id);records.append(row);stream.write(json.dumps(row)+'\n');stream.flush()
        print(json.dumps({'case_completed':i+1,'total':len(roster),'stratum':case['stratum'],'outcome':row['outcome'],'elapsed':row['elapsed'],'evaluation_wall_seconds':time.monotonic()-start}),flush=True)
        if row['outcome']=='infrastructure':break
    stream.close();verify_protected();result=aggregate(roster,records);resources={'parent_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'completed_child_peak_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'memory_available_after':next(line for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')),'evaluation_wall_seconds':time.monotonic()-start,'startup_seconds':sum(r['startup_seconds'] for r in records),'active_seconds':sum(r['elapsed'] for r in records),'cleanup_seconds':sum(r['cleanup_seconds'] for r in records),'audit_copy_seconds':sum(r['audit_copy_seconds'] for r in records),'overall_evaluation_guard_seconds':guard}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'resources.json').write_text(json.dumps(resources,indent=2)+'\n');(out/'feedback.json').write_text(json.dumps(feedback(result,resources),indent=2)+'\n');return result
