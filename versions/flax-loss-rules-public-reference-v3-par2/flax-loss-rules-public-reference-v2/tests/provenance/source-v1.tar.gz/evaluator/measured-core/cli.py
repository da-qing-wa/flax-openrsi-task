"""Local Stage C entry points, unrelated to official organizer/Harness interfaces."""
import argparse,json,os,re,sys,time
from pathlib import Path
from inventory import ROOT,CHECKOUT,PROTOCOL,sha,build
from contract import verify_protected,candidate_manifest,reference_candidate
from evaluator import evaluate,clean_env,PYTHON
from supervision import bounded_process
from metrics import aggregate

def write(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n')
def train(candidate,run_id):
    if not run_id or not re.fullmatch('[A-Za-z0-9_-]+',run_id):raise ValueError('Unsafe run ID')
    verify_protected();candidate_manifest(candidate)
    out=ROOT/'runs'/run_id
    if out.exists():raise FileExistsError(out)
    result=bounded_process([str(PYTHON),'-u',str(ROOT/'train.py'),'--candidate',str(candidate),'--run-id',run_id],CHECKOUT,clean_env(),ROOT/'runs'/f'{run_id}.training.log',3600.)
    write(ROOT/'runs'/f'{run_id}.supervision.json',result)
    if result['limit_exceeded'] or result['exit_status']!=0 or not result['cleanup']['ok']:raise RuntimeError('candidate_invalid: training did not complete within fixed budget')
    final=out/'model/final_seed0_Mazenamo.pt'
    if not final.is_file():raise RuntimeError('candidate_invalid: missing final checkpoint')
    verify_protected();return final

def guarded_evaluation(checkpoint,out,run_id,candidate_id,mode='fixed',cases=None,remaining_guard=None):
    if mode=='fixed' and cases is not None:raise ValueError('Fixed evaluation forbids case selection')
    roster=json.loads((ROOT/'manifests'/('evaluation.json' if mode=='fixed' else 'development.json')).read_text())
    if cases is not None:
        requested=set(cases);roster=[c for c in roster if c['group_id'] in requested]
        if {c['group_id'] for c in roster}!=requested:raise ValueError('Requested case is not development')
    limit=300+sum((20 if c['stratum'].startswith('12') else 40)+65 for c in roster)
    if remaining_guard is not None:limit=min(limit,remaining_guard)
    out=Path(out).resolve()
    if not out.is_relative_to((ROOT/'runs').resolve()):raise ValueError('Evaluation outputs must be inside Stage C runs')
    if out.exists():raise FileExistsError(out)
    command=[str(PYTHON),'-u',str(ROOT/'cli.py'),'evaluate_internal','--checkpoint',str(checkpoint),'--output',str(out),'--run-id',run_id,'--candidate-id',candidate_id,'--mode',mode]
    for c in cases or []:command+=['--case',c]
    result=bounded_process(command,CHECKOUT,clean_env(),Path(str(out)+'.log'),limit)
    write(Path(str(out)+'.supervision.json'),result)
    if result['limit_exceeded'] or result['exit_status']!=0 or not result['cleanup']['ok']:
        out.mkdir(exist_ok=True);unscored={'status':'infrastructure_unscored','primary_score':None,'diagnostic':'evaluation_guard_or_process_failure'};write(out/'result.json',unscored);write(out/'feedback.json',{'status':unscored['status'],'primary_score':None,'diagnostics':['Evaluation infrastructure did not complete.']});return unscored
    return json.loads((out/'result.json').read_text())

def trial(candidate,run_id,reference=False):
    started=time.monotonic();verify_protected();c=reference_candidate(candidate) if reference else candidate_manifest(candidate);ledger=ROOT/'runs'/f'{run_id}.trial.json'
    if ledger.exists():raise FileExistsError(ledger)
    write(ledger,{'status':'running','run_id':run_id,'candidate_id':c['candidate_id'],'reference':reference,'started_unix':time.time(),'protocol_sha256':sha(ROOT/'protocol.json')})
    roster=json.loads((ROOT/'manifests/evaluation.json').read_text());overall=3600+300+sum((20 if r['stratum'].startswith('12') else 40)+65 for r in roster)
    try:
        checkpoint=train(candidate,run_id);training_end=time.monotonic()
        if reference:
            # Separate fixed comparison process: never initialize training from historical weights.
            comparison=bounded_process([str(PYTHON),'-u',str(ROOT/'compare_reference.py'),'--run-id',run_id],CHECKOUT,clean_env(),ROOT/'runs'/f'{run_id}.comparison.log',min(300.,overall-(time.monotonic()-started)))
            if comparison['exit_status']!=0:raise RuntimeError('Reference model differs or comparison failed; evaluation NOT RUN')
        result=guarded_evaluation(checkpoint,ROOT/'runs'/f'{run_id}-evaluation',run_id,c['candidate_id'],remaining_guard=overall-(time.monotonic()-started))
        status=result['status'];score=result['primary_score']
        write(ledger,{'status':status,'primary_score':score,'reference':reference,'fresh_training':True,'checkpoint_sha256':sha(checkpoint),'protocol_sha256':sha(ROOT/'protocol.json'),'training_and_serialization_wall_seconds':training_end-started,'evaluation_and_comparison_wall_seconds':time.monotonic()-training_end,'trial_wall_seconds':time.monotonic()-started,'overall_trial_guard_seconds':overall})
    except BaseException as exc:
        write(ledger,{'status':'unscored','primary_score':None,'error':repr(exc),'trial_wall_seconds':time.monotonic()-started});raise

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['inventory_and_split','train_fixed','evaluate_dev','evaluate_fixed','evaluate_internal','run_reference_trial','run_candidate_trial','aggregate_and_report']);p.add_argument('--candidate',type=Path);p.add_argument('--run-id');p.add_argument('--candidate-id',default='reference-bce');p.add_argument('--checkpoint',type=Path);p.add_argument('--output',type=Path);p.add_argument('--mode',choices=['fixed','dev'],default='fixed');p.add_argument('--case',action='append');p.add_argument('--records',type=Path);args=p.parse_args()
    if args.candidate is not None and not args.candidate.is_absolute():args.candidate=ROOT/args.candidate
    if args.run_id is not None and not re.fullmatch('[A-Za-z0-9_-]+',args.run_id):raise ValueError('Unsafe run ID')
    if args.command=='inventory_and_split':
        value=build()
        for name,records in value.items():
            path=ROOT/'manifests'/f'{name}.json'
            if path.exists():
                if json.loads(path.read_text())!=records:raise ValueError('Manifest regeneration differs; refusing overwrite')
            else:write(path,records)
        print(json.dumps(value['counts']));return
    if args.command=='aggregate_and_report':
        verify_protected()
        roster=json.loads((ROOT/'manifests/evaluation.json').read_text());records=[json.loads(line) for line in args.records.read_text().splitlines()];result=aggregate(roster,records)
        if args.output.exists():raise FileExistsError(args.output)
        write(args.output,result);print(json.dumps(result));return
    if args.case and args.command!='evaluate_dev' and not (args.command=='evaluate_internal' and args.mode=='dev'):raise ValueError('Case selection is development-only')
    verify_protected()
    if args.command=='train_fixed':train(args.candidate,args.run_id)
    elif args.command in ['run_reference_trial','run_candidate_trial']:
        candidate=ROOT/'candidates/reference/manifest.json' if args.command=='run_reference_trial' else args.candidate
        trial(candidate,args.run_id,args.command=='run_reference_trial')
    elif args.command=='evaluate_internal':
        roster=json.loads((ROOT/'manifests'/('evaluation.json' if args.mode=='fixed' else 'development.json')).read_text())
        if args.case:
            requested=set(args.case);roster=[r for r in roster if r['group_id'] in requested]
            if {r['group_id'] for r in roster}!=requested:raise ValueError('Unassigned development case')
        result=evaluate(roster,args.checkpoint,args.output,args.run_id,args.candidate_id)
        if args.mode=='dev':
            # Detailed records available; partial development does not claim a primary Judge score.
            write(args.output/'development-result.json',{'status':'complete' if len(list((args.output/'audit').glob('*/record.json')))==len(roster) else 'incomplete','purpose':'development diagnostics only'})
    else:
        if args.command=='evaluate_dev' and not args.case:raise ValueError('Explicit development case IDs required')
        guarded_evaluation(args.checkpoint,args.output,args.run_id,args.candidate_id,'dev' if args.command=='evaluate_dev' else 'fixed',args.case)
if __name__=='__main__':main()
