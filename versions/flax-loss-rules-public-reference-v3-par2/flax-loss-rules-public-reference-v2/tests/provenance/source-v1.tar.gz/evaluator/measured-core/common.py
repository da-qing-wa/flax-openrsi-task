"""Fixed local execution and evidence helpers; no research protocol additions."""
import hashlib, json, os, pickle, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
A=ROOT.parent/'stage_a_20261004'
CHECKOUT=ROOT/'flax'
CACHE=ROOT/'data/training_data_Mazenamo.pkl'
CACHE_SHA='6622009ab767a0d2db5d40a5e6efa577820569ed88a7dca804ac0d4c09db7a8c'
assert os.environ['PYTHONHASHSEED']=='0'
assert os.environ['PYTHONDONTWRITEBYTECODE']=='1'
assert os.environ['OMP_NUM_THREADS']==os.environ['MKL_NUM_THREADS']=='1'
assert sorted(os.sched_getaffinity(0))==[0,1,2,3]
assert Path.cwd()==CHECKOUT or (Path.cwd()/'stage-c-case-root').is_file()
sys.path[:0]=[str(CHECKOUT),str(CHECKOUT/'src')]
TMP=Path(os.environ['FLAXC_TMP_DIR']) if 'FLAXC_TMP_DIR' in os.environ else Path(tempfile.mkdtemp(prefix='flaxC-',dir='/tmp'))
os.environ['TMPDIR']=str(TMP); tempfile.tempdir=str(TMP)
import torch, numpy as np, pddlgym
from pddlgym.structs import LiteralConjunction
from guidance.gnn_guidance import GNNSearchGuidance
from gnn.gnn_dataset import GraphDictDataset, graph_batch_collate
from gnn.gnn import setup_graph_net
from guidance.reference_loss import compute_loss
from gnn import gnn_utils

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,obj): Path(path).write_text(json.dumps(obj,indent=2)+'\n')
def reserve(path): Path(path).mkdir(exist_ok=False); return Path(path)
def checked_cache(path=CACHE,expected=CACHE_SHA):
    if not Path(path).is_file(): raise FileNotFoundError(path)
    if sha(path)!=expected: raise ValueError('Frozen cache SHA-256 mismatch')
    with Path(path).open('rb') as f: data=pickle.load(f)
    if len(data[0])!=195 or len(data[1])!=195: raise ValueError('Frozen label count mismatch')
    return data
class ForbiddenTeacher:
    def __call__(self,*a,**kw): raise RuntimeError('Stage C prohibits teacher collection')
def guider(callback=None,output=None):
    return GNNSearchGuidance(ForbiddenTeacher(),200,301,'bce',10,False,True,
        str(CACHE.parent/'training_data'),str((output or ROOT/'unused')/'final_seed0'),True,
        compute_loss=callback)
def schema(g):
    return {'node_features':{str(k):v for k,v in g._node_feature_to_index.items()},
            'edge_features':{str(k):v for k,v in g._edge_feature_to_index.items()}}
def graphs(g):
    data=checked_cache(); inputs,targets=g._create_graph_dataset(data)
    s=schema(g); assert s==json.loads((A/'artifacts/full/feature-schema.json').read_text())
    return GraphDictDataset(inputs[19:],targets[19:]),GraphDictDataset(inputs[:19],targets[:19])
def tensor_digest(mapping):
    h=hashlib.sha256()
    for k,v in mapping.items():
        h.update(str(k).encode())
        if v is None: h.update(b'None'); continue
        t=v.detach().cpu().contiguous(); h.update(str((t.dtype,tuple(t.shape))).encode()); h.update(t.numpy().tobytes())
    return h.hexdigest()
def comparison(a,b):
    diffs=[]; mx=0.0
    for k in a.keys()|b.keys():
        if k not in a or k not in b or not torch.equal(a[k],b[k]):
            diffs.append(k)
            if k in a and k in b and a[k].shape==b[k].shape: mx=max(mx,float((a[k]-b[k]).abs().max()))
            else: mx=float('inf')
    return {'tensor_equal':not diffs,'max_abs_diff':mx,'differing_tensors':diffs}
def provenance():
    import guidance.gnn_guidance, gnn.gnn, gnn.gnn_dataset, planning, minigrid
    modules={m.__name__:str(Path(m.__file__).resolve()) for m in [guidance.gnn_guidance,gnn.gnn,gnn.gnn_dataset,gnn_utils,pddlgym,planning,minigrid]}
    for n,p in modules.items():
        if n!='minigrid': assert Path(p).is_relative_to(CHECKOUT),modules
    import importlib.metadata as md
    versions={d.metadata['Name']:d.version for d in md.distributions()}
    return {'python':sys.version,'executable':sys.executable,'torch':torch.__version__,'modules':modules,
      'dependencies':versions,'sources':json.loads((A/'artifacts/sources.lock.json').read_text()),
      'cwd':str(Path.cwd()),'affinity':sorted(os.sched_getaffinity(0)),
      'environment':{k:os.environ.get(k) for k in ['PYTHONHASHSEED','PYTHONDONTWRITEBYTECODE','PYTHONPATH','OMP_NUM_THREADS','MKL_NUM_THREADS','TMPDIR']},
      'torch_num_threads':torch.get_num_threads(),'patch_sha256':sha(ROOT/'changes.patch'),
      'loss_source_sha256':sha(CHECKOUT/'guidance/reference_loss.py')}
