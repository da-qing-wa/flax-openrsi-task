"""Fixed fresh-guider case worker; sends actual plan for independent validation."""
import argparse,json,os,resource,socket,subprocess,time,traceback
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--fd',type=int,required=True);parser.add_argument('--checkpoint',required=True);parser.add_argument('--case',required=True);parser.add_argument('--audit',required=True);parser.add_argument('--deadline',type=float,required=True);args=parser.parse_args()
control=socket.socket(fileno=args.fd);audit=Path(args.audit)
def send(obj):control.sendall((json.dumps(obj)+'\n').encode())
try:
    import_started=time.monotonic()
    from scorer import *
    from planning import FlaxPlanner,PlanningFailure,PlanningTimeout
    from my_utils.pddl_utils import _create_planner
    imports_done=time.monotonic();domain,state=parse_problem(args.case);parse_done=time.monotonic();g=load_scorer(args.checkpoint,domain);model_done=time.monotonic()
    planner=FlaxPlanner(is_strips_domain=True,base_planner=_create_planner('fd-lama-first'),search_guider=g,seed=0,complementary_rules='config/mazenamo_complementary_rules.json',relaxation_rules='config/mazenamo_relaxation_rules_1.json')
    assert g._last_processed_state is None
    statuses=[];counter=0
    def observed(command,*a,**kw):
        global counter
        counter+=1;began=time.monotonic();stem=audit/f'subprocess-{counter:04d}'
        (Path(str(stem)+'.command')).write_text(command+'\n')
        with Path(str(stem)+'.log').open('wb') as out:
            p=subprocess.Popen(command,shell=True,stdout=out,stderr=subprocess.STDOUT)
            Path(str(stem)+'.launch.json').write_text(json.dumps({'id':counter,'command':command,'shell_pid':p.pid})+'\n')
            status=p.wait()
        text=Path(str(stem)+'.log').read_text(errors='replace').rstrip('\n')
        row={'id':counter,'command':command,'exit_status':status,'seconds':time.monotonic()-began,'log':str(stem.name)+'.log'};statuses.append(row)
        with (audit/'subprocesses.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        return text
    subprocess.getoutput=observed
    send({'kind':'READY','model_loaded':True,'original_pddl_parsed':True,'case_graph_constructed':False,'guider_cache_empty':True,'imports':provenance()['modules'],'import_seconds':imports_done-import_started,'pddl_parse_seconds':parse_done-imports_done,'model_load_seconds':model_done-parse_done,'startup_max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    if control.recv(3)!=b'GO\n':raise ValueError('Missing GO')
    try:
        plan,vis=planner(domain,state,timeout=40)
        send({'kind':'RESULT','plan':[act.pddl_str() for act in plan],'statuses':statuses})
    except (PlanningTimeout,PlanningFailure) as exc:
        send({'kind':'RESULT','plan':None,'exception':type(exc).__name__,'error':str(exc),'statuses':statuses})
except BaseException:
    error=traceback.format_exc();(audit/'worker-failure.log').write_text(error)
    try:send({'kind':'ERROR','error':error})
    except OSError:pass
finally:
    control.close()
