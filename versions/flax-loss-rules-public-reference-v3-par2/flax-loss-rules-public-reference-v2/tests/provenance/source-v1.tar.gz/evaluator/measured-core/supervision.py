"""Supported POSIX session supervision, including orphan descendants in new groups."""
import json,os,signal,subprocess,time
from pathlib import Path

def session_members(sid):
    members=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            # comm can contain spaces/parentheses; fields after its final ')' start at state.
            fields=(p/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[3])==sid and fields[0]!='Z':members.append(int(p.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return members
def cleanup(sids,grace=5.):
    start=time.monotonic();initial={sid:session_members(sid) for sid in sids}
    def signal_all(sig):
        for sid in sids:
            # An exited session leader can leave live grandchildren; do not rely on p.poll().
            for pid in session_members(sid):
                try:os.kill(pid,sig)
                except ProcessLookupError:pass
    signal_all(signal.SIGTERM)
    until=start+grace
    while any(session_members(sid) for sid in sids) and time.monotonic()<until:time.sleep(.02)
    signal_all(signal.SIGKILL)
    until=time.monotonic()+.5
    while any(session_members(sid) for sid in sids) and time.monotonic()<until:time.sleep(.01)
    remaining={sid:session_members(sid) for sid in sids}
    return {'seconds':time.monotonic()-start,'initial_pids':initial,'remaining_pids':remaining,'ok':not any(remaining.values())}
def register_session(sid,active=True):
    registry=os.environ.get('FLAXC_SESSION_REGISTRY')
    if registry:
        with Path(registry).open('a') as f:f.write(json.dumps({'sid':sid,'active':active})+'\n')
def registered_sessions(registry):
    active=set()
    if registry.is_file():
        for line in registry.read_text().splitlines():
            event=json.loads(line)
            if event['active']:active.add(event['sid'])
            else:active.discard(event['sid'])
    return active
def bounded_process(command,cwd,env,log,limit):
    started=time.monotonic();registry=Path(str(log)+'.sessions.jsonl');env=dict(env,FLAXC_SESSION_REGISTRY=str(registry))
    with Path(log).open('xb') as stream:
        p=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        exceeded=False
        try:p.wait(timeout=limit)
        except subprocess.TimeoutExpired:exceeded=True
        cleaned=cleanup([p.pid]+sorted(registered_sessions(registry)));p.wait()
    return {'exit_status':p.returncode,'limit_exceeded':exceeded,'seconds':time.monotonic()-started,'cleanup':cleaned}
