"""Fresh model and complete training trace comparison with locked Stage B evidence."""
import argparse,shutil
from common import *
p=argparse.ArgumentParser();p.add_argument('--run-id',required=True);args=p.parse_args();out=ROOT/'runs'/args.run_id;B=ROOT.parent/'stage_b_20261004T230932Z';reference=B/'runs/callback-01'
comparisons={}
for name in ['initial.pt','initial-torch-rng.pt','model/final_seed0_Mazenamo.pt','checkpoints/model300.pt']:
    x=torch.load(out/name,map_location='cpu',weights_only=True);y=torch.load(reference/name,map_location='cpu',weights_only=True)
    comparisons[name]=comparison(x,y) if isinstance(x,dict) else {'tensor_equal':torch.equal(x,y)}
    assert comparisons[name]['tensor_equal'],name
rows=[json.loads(l) for l in (out/'loss-trace.jsonl').read_text().splitlines()];old=[json.loads(l) for l in (reference/'loss-trace.jsonl').read_text().splitlines()]
assert rows==old,'Training trace divergence'
assert len(rows)==3373 and sum(r['phase']=='train' for r in rows)==3311 and sum(r['phase']=='val' for r in rows)==62
assert sum(len(r['instance_indices']) for r in rows if r['phase']=='val')==589
assert len({r['epoch'] for r in rows if r['phase']=='val'})==31
assert json.loads((out/'scorer-metadata.json').read_text())['feature_schema']==json.loads((ROOT/'feature-schema.json').read_text())
dump(out/'stage-b-comparison.json',{'status':'PASS','tensor_comparisons':comparisons,'all_training_and_validation_traces_identical':True,'optimizer_updates':3311,'training_graph_exposures':52976,'validation_phases':31,'validation_forwards':62,'validation_graph_exposures':589,'feature_schema_equal':True});print('PASS: fresh model, initialization/RNG and every batch trace exactly match Stage B');shutil.rmtree(TMP)
