"""Public PDDL inventory, conservative content grouping, fixed hash allocation."""
import hashlib,json,math,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent; A=ROOT.parent/'stage_a_20261004';B=ROOT.parent/'stage_b_20261004T230932Z'
CHECKOUT=ROOT/'flax';PROTOCOL='flax-loss-public-reference-v1'
STRATA=[f'{size}x{size}_{level}' for size in (12,15) for level in ('easy','medium','hard','expert')]
DOMAIN=CHECKOUT/'pddl_files/domains/mazenamo.pddl'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def parse(text):
    tokens=re.findall(r'\(|\)|[^\s()]+',re.sub(r';[^\n]*','',text.lower())); stack=[];root=[]
    for t in tokens:
        if t=='(':
            child=[]
            (stack[-1] if stack else root).append(child);stack.append(child)
        elif t==')':
            if not stack:raise ValueError('Unbalanced PDDL')
            stack.pop()
        else:
            if not stack:raise ValueError('Token outside expression')
            stack[-1].append(t)
    if stack or len(root)!=1:raise ValueError('Unbalanced PDDL')
    return root[0]
def canonical(text,domain_sha):
    p=parse(text)
    if p[0]!='define' or p[1][0]!='problem' or len(p[1])!=2:raise ValueError('Unsupported problem header')
    fields={}
    for section in p[2:]:
        if not isinstance(section,list) or section[0] in fields:raise ValueError('Unsupported/duplicate section')
        fields[section[0]]=section[1:]
    if set(fields)!={':domain',':objects',':init',':goal'} or fields[':domain']!=['mazenamo']:raise ValueError('Unsupported problem sections/domain')
    objs=[];pending=[];declarations=fields[':objects'];i=0
    while i<len(declarations):
        t=declarations[i]
        if not isinstance(t,str):raise ValueError('Unsupported object declaration')
        if t=='-':
            if not pending or i+1>=len(declarations) or declarations[i+1] not in ('robot','pos','obstacle'):raise ValueError('Unsupported object type')
            objs.extend((n,declarations[i+1]) for n in pending);pending=[];i+=2
        else:pending.append(t);i+=1
    if pending or len({n for n,t in objs})!=len(objs):raise ValueError('Untyped/duplicate object')
    names={n for n,t in objs}
    arities={'upon':2,'onground':1,'clear':1,'holding':2,'handempty':0,'dirisup':1,'dirisdown':1,'dirisleft':1,'dirisright':1,'rat':2,'oat':2,'upto':2,'downto':2,'leftto':2,'rightto':2,'isheavy':1,'islight':1,'ismoveable':1,'posempty':1}
    def atom(a):
        if not isinstance(a,list) or not a or a[0] not in arities or len(a)!=arities[a[0]]+1 or any(not isinstance(x,str) or x not in names for x in a[1:]):raise ValueError('Unsupported predicate/formula')
        return tuple(a)
    initial=sorted(atom(a) for a in fields[':init'])
    goal=fields[':goal']
    if len(goal)!=1:raise ValueError('Unsupported goal')
    g=goal[0]; goals=sorted(atom(a) for a in g[1:]) if g and g[0]=='and' else [atom(g)]
    # Multiplicity is retained conservatively; no object renaming or logical simplification.
    return digest({'domain_sha256':domain_sha,'objects':sorted(objs),'init':initial,'goal_conjunction':goals})
def rank(namespace,stratum,gid):return hashlib.sha256(f'{PROTOCOL}\0{namespace}\0{stratum}\0{gid}'.encode()).hexdigest()
def allocate(groups):
    counts={}; splits={'development':[],'evaluation':[],'unused':[]}
    for s in STRATA:
        eligible=[g for g in groups if g['stratum']==s and not g['training_overlap']]
        forced=[g for g in eligible if g['forced_development']]; target=max(math.ceil(.2*len(eligible)),len(forced))
        dev=forced+sorted([g for g in eligible if not g['forced_development']],key=lambda g:rank('development-allocation',s,g['group_id']))[:target-len(forced)]
        ids={g['group_id'] for g in dev};remaining=sorted([g for g in eligible if g['group_id'] not in ids],key=lambda g:rank('evaluation-roster',s,g['group_id']))
        ev=remaining[:50];unused=remaining[50:]
        for key,items in [('development',dev),('evaluation',ev),('unused',unused)]:splits[key].extend(dict(g['representative'],group_id=g['group_id'],split=key) for g in sorted(items,key=lambda g:g['group_id']))
        counts[s]={'eligible_distinct_groups':len(eligible),'forced_development':len(forced),'development':len(dev),'evaluation':len(ev),'unused':len(unused)}
    if any(c['evaluation']==0 for c in counts.values()):raise ValueError('Empty primary evaluation stratum')
    return splits,counts
def build(reverse=False):
    domain_sha=sha(DOMAIN); historical=json.loads((B/'evidence/exposure-ledger.json').read_text()); exposures={r['instance']['path']:r for r in historical}
    forced={r['instance']['path'] for r in historical if 'planning/VAL execution-path coverage' in r['stage_b_purpose']}
    for path in (A/'artifacts').glob('smoke*/assigned-tests.json'):
        for r in json.loads(path.read_text()):forced.add(r['path'])
    labels=json.loads((A/'artifacts/full/successful-labels.json').read_text()); rows=[];train_ids=set();base=CHECKOUT/'pddl_files/problems/mazenamo_problems'
    for r in labels['ordered_instances']:
        if sha(CHECKOUT/r['path'])!=r['sha256']:raise ValueError('Training source hash mismatch')
        train_ids.add(canonical((CHECKOUT/r['path']).read_text(),domain_sha))
    paths=[p for s in STRATA for p in (base/f'pddl_{s}').glob('*.pddl')];paths=sorted(paths,reverse=reverse)
    for p in paths:
        rel=str(p.relative_to(CHECKOUT));s=p.parent.name.removeprefix('pddl_');old=exposures.get(rel)
        if old and sha(p)!=old['instance']['sha256']:raise ValueError('Exposed source hash mismatch')
        gid=canonical(p.read_text(),domain_sha)
        rows.append({'path':rel,'sha256':sha(p),'stratum':s,'group_id':gid,'domain_sha256':domain_sha,'source_revision':'42a10303a7126d411155e6e69447e449e2b23a9f','provenance':'released public Flax PDDL','exposure':'exposed_reference' if old else 'public_origin','forced_development':rel in forced,'access_purpose':'syntax/inventory/fingerprint audit; historical fixed-baseline evaluation' if old else 'syntax/inventory/fingerprint audit; no candidate feedback'})
    groups={}
    for r in rows:groups.setdefault(r['group_id'],[]).append(r)
    ledger=[]
    for gid,members in sorted(groups.items()):
        strata={m['stratum'] for m in members}
        if len(strata)!=1:raise ValueError(f'Conflicting duplicate stratum: {gid}: {sorted(strata)}')
        ledger.append({'group_id':gid,'stratum':members[0]['stratum'],'members':sorted(members,key=lambda m:m['path']),'representative':min(members,key=lambda m:m['path']),'forced_development':any(m['forced_development'] for m in members),'training_overlap':gid in train_ids})
    splits,counts=allocate(ledger); exact={}
    for r in rows:exact.setdefault(r['sha256'],[]).append(r['path'])
    return {'inventory':sorted(rows,key=lambda r:r['path']),'duplicates':ledger,'exact_byte_duplicate_groups':[v for k,v in sorted(exact.items()) if len(v)>1],'counts':counts,**splits,'train':labels['training'],'validation':labels['validation'],'exposure':sorted(rows,key=lambda r:r['path'])}
if __name__=='__main__':
    import time,traceback
    t=time.monotonic()
    try:
        result=build()
        for name,value in result.items():(ROOT/'manifests'/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
        print(json.dumps({'status':'PASS','seconds':time.monotonic()-t,'counts':result['counts']}))
    except Exception:
        (ROOT/'evidence/inventory-failure.log').write_text(traceback.format_exc());raise
