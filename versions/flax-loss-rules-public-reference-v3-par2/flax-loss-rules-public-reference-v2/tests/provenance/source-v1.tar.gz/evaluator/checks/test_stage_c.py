"""Protocol arithmetic, fail-closed boundaries, and real-process cleanup tests."""
import copy,json,os,shutil,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from inventory import *
from metrics import *
from contract import candidate_manifest
from evaluator import classify_failure,validation_outcome,clean_env,PYTHON
from supervision import cleanup,session_members,bounded_process
START=time.monotonic();RESULTS={};TMP=Path(tempfile.mkdtemp(prefix='flaxC-tests-',dir='/tmp'))
def sample():
    roster=[];records=[]
    for i,s in enumerate(STRATA):
        for j in range(1+(i==0)):
            case={'group_id':f'{i}-{j}','sha256':f'h{i}{j}','stratum':s};roster.append(case);T=20. if s.startswith('12') else 40.
            record={'run_id':'fixture','candidate_id':'fixture','checkpoint_sha256':'a'*64,'seed':0,'protocol_sha256':sha(ROOT/'protocol.json') if (ROOT/'protocol.json').exists() else None,'protocol_id':PROTOCOL,'instance_id':case['group_id'],'instance_sha256':case['sha256'],'stratum':s,'outcome':'valid','original_plan_validity':True,'elapsed':1.,'deadline':T,'plan_length':3,'utility':1-1/(10*T)};records.append(record)
    return roster,records
class Tests(unittest.TestCase):
    def test_inventory_determinism_exposure_and_disjointness(self):
        a=build();b=build(reverse=True);self.assertEqual(a,b)
        self.assertEqual(len([r for r in a['exposure'] if r['exposure']=='exposed_reference']),100)
        ids={name:{r['group_id'] for r in a[name]} for name in ['development','evaluation','unused']}
        for name in ids:
            for other in ids:
                if name!=other:self.assertFalse(ids[name]&ids[other])
        forced={r['group_id'] for r in a['inventory'] if r['forced_development']};self.assertEqual(len(forced),5);self.assertTrue(forced<=ids['development'])
        RESULTS['inventory']={'repeat_reverse_traversal_identical':True,'exposed_reference_count':100,'forced_development_count':5,'counts':a['counts'],'split_disjointness':True}
    def test_canonical_supported_and_unsupported(self):
        one='(define (problem a) (:domain mazenamo) (:objects r - robot p - pos q - pos) (:init (rat r p) (rightto p q)) (:goal (and (rat r q) (handempty))))'
        two='; comment\n(DEFINE (problem b) (:goal (and (handempty) (rat r q))) (:init (rightto p q) (rat r p)) (:objects q p - pos r - robot) (:domain mazenamo))'
        self.assertEqual(canonical(one,'D'),canonical(two,'D'));self.assertNotEqual(canonical(one,'D'),canonical(one,'E'))
        for bad in [one.replace('(and (rat r q) (handempty))','(or (rat r q) (handempty))'),one.replace('(:init','(:metric minimize (total-cost)) (:init'),one.replace('(rat r p)','(unknown r p)')]:
            with self.assertRaises(ValueError):canonical(bad,'D')
        self.assertNotEqual(canonical(one,'D'),canonical(one.replace('(rat r p)','(rat r q)'),'D'))
        groups=[{'group_id':f'{s}-{i}','stratum':s,'forced_development':i==0,'training_overlap':i==1,'representative':{'path':f'{s}/{i}'}} for s in STRATA for i in range(5)]
        split,counts=allocate(groups)
        self.assertTrue(all(c['eligible_distinct_groups']==4 and c['forced_development']==1 for c in counts.values()));self.assertTrue(all(r['group_id'].endswith('-0') for r in split['development']))
        with self.assertRaises(ValueError):allocate([])
        RESULTS['duplicates']={'presentation_variants_equal':True,'changed_domain_or_fact_not_equal':True,'unsupported_constructs_rejected':True,'forced_development_and_training_overlap_rules':True,'empty_strata_fail_closed':True}
    def test_metrics_and_completeness(self):
        self.assertEqual(utility('valid',0.,20.,True),1.)
        self.assertEqual(utility('valid',20.,20.,True),.9)
        self.assertEqual(utility('valid',20.001,20.,True),0.)
        for o in ['no_plan','invalid_plan','deadline']:self.assertEqual(utility(o,1.,20.,False),0.)
        roster,records=sample();records[0].update(outcome='deadline',original_plan_validity=None,utility=0.)
        result=aggregate(roster,records);self.assertEqual(result['status'],'complete')
        macro=93.40625;self.assertEqual(result['primary_score'],macro)
        self.assertNotEqual(result['primary_score'],100*sum(r['utility'] for r in records)/len(records))
        self.assertEqual(result,aggregate(roster,json.loads(json.dumps(records))))
        for changed in [records[:-1],records+[records[0]],records[:-1]+[records[0]]]:self.assertIsNone(aggregate(roster,changed)['primary_score'])
        changed=copy.deepcopy(records);changed[1]['outcome']='infrastructure';self.assertIsNone(aggregate(roster,changed)['primary_score'])
        changed=copy.deepcopy(records);changed[1]['seed']=1;self.assertIsNone(aggregate(roster,changed)['primary_score'])
        changed=copy.deepcopy(records);changed[1]['checkpoint_sha256']='different';self.assertIsNone(aggregate(roster,changed)['primary_score'])
        changed=copy.deepcopy(records);changed[1]['elapsed']=21.;changed[1]['utility']=0.;self.assertIsNone(aggregate(roster,changed)['primary_score'])
        f=feedback(result,{'wall_seconds':1.});self.assertNotIn('instance_id',json.dumps(f));self.assertNotIn('outcome_counts',json.dumps(f))
        RESULTS['metrics']={'correct_deadline_arithmetic':True,'late_validation_zero_not_clipped_success':True,'ordinary_failures_zero':True,'macro_weighting_unequal_counts':True,'incomplete_duplicate_extra_infrastructure_unscored':True,'independent_reaggregation_exact':True,'sanitized_feedback':True}
    def test_candidate_paths(self):
        base=ROOT/'candidates'/'test-fixture';base.mkdir(exist_ok=False)
        try:
            (base/'loss.py').write_text('def compute_loss(*a,**kw): pass\n');manifest={'candidate_id':'fixture','loss_path':'loss.py','loss_sha256':sha(base/'loss.py'),'abi_version':'compute_loss-v1','description':'test only'};p=base/'manifest.json';p.write_text(json.dumps(manifest));self.assertTrue(candidate_manifest(p)['resolved_loss'].endswith('loss.py'))
            for change in [dict(manifest,timeout=1),dict(manifest,loss_path='../reference/loss.py'),dict(manifest,loss_path='missing.py'),dict(manifest,loss_sha256='bad')]:
                p.write_text(json.dumps(change))
                with self.assertRaises(ValueError):candidate_manifest(p)
            (base/'escape.py').symlink_to(ROOT/'common.py');p.write_text(json.dumps(dict(manifest,loss_path='escape.py',loss_sha256=sha(ROOT/'common.py'))))
            with self.assertRaises(ValueError):candidate_manifest(p)
            self.assertNotIn('candidate_loss',sys.modules)
            self.assertNotIn('spec_from_file_location',(ROOT/'evaluator.py').read_text())
        finally:shutil.rmtree(base)
        RESULTS['candidate_boundary']={'unknown_overrides_missing_wrong_hash_traversal_symlink_escape_rejected':True,'candidate_module_not_imported_by_authoritative_evaluator':True}
    def test_real_cleanup_hang_and_orphan(self):
        # Real hanging worker and separately supervised validator use identical launcher/cleanup code.
        for name in ['hanging-worker','hanging-validator']:
            r=bounded_process([str(PYTHON),'-c','import time;time.sleep(30)'],CHECKOUT,clean_env(),TMP/f'{name}.log',.15)
            self.assertTrue(r['limit_exceeded']);self.assertTrue(r['cleanup']['ok'])
        pidfile=TMP/'grandchild.pid'
        script="import subprocess,os; p=subprocess.Popen(['"+str(PYTHON)+"','-c','import time,os;os.setpgrp();time.sleep(30)']);open('"+str(pidfile)+"','w').write(str(p.pid))"
        p=subprocess.Popen([str(PYTHON),'-c',script],start_new_session=True,env=clean_env());p.wait(timeout=2);self.assertTrue(session_members(p.pid));r=cleanup([p.pid],.1);self.assertTrue(r['ok']);self.assertFalse(session_members(p.pid))
        with patch('supervision.session_members',return_value=[999999]),patch('supervision.os.kill'):
            r=cleanup([999999],0.);self.assertFalse(r['ok'])
        RESULTS['process_cleanup']={'real_hanging_worker_terminated':True,'real_hanging_validator_terminated':True,'orphan_grandchild_new_process_group_terminated':True,'failed_cleanup_surfaced':True}
    def test_whole_guard_registered_independent_session(self):
        script="import os,json,subprocess,time; p=subprocess.Popen(['"+str(PYTHON)+"','-c','import time;time.sleep(30)'],start_new_session=True);open(os.environ['FLAXC_SESSION_REGISTRY'],'a').write(json.dumps({'sid':p.pid,'active':True})+'\\n');time.sleep(30)"
        r=bounded_process([str(PYTHON),'-c',script],CHECKOUT,clean_env(),TMP/'whole-guard.log',.2)
        self.assertTrue(r['limit_exceeded']);self.assertTrue(r['cleanup']['ok']);self.assertGreaterEqual(len(r['cleanup']['initial_pids']),2)
        RESULTS['whole_guard']={'independent_registered_child_session_terminated':True}
    def test_failure_mapping_and_real_val(self):
        for code in [10,11,12,20,21,22,23,24,124]:self.assertEqual(classify_failure({'exception':'PlanningFailure','statuses':[{'command':'fast-downward.py original','exit_status':code}]}),'no_plan')
        for code in [0,30,31,32,33,34,35,36,37,-9,127]:self.assertEqual(classify_failure({'exception':'PlanningFailure','statuses':[{'command':'fast-downward.py original','exit_status':code}]}),'infrastructure')
        self.assertEqual(classify_failure({'exception':'PlanningFailure','statuses':[]}),'infrastructure')
        val=CHECKOUT/'VAL/build/linux64/Release/bin/Validate';problem=CHECKOUT/'pddl_files/problems/mazenamo_problems/pddl_10x10_train/mazenamo_problem_300.pddl';valid=A/'artifacts/validator/subprocesses/00004.input4';bad=TMP/'invalid.plan';bad.write_text('')
        statuses=[]
        for name,plan,expected in [('valid',valid,'valid'),('invalid',bad,'invalid_plan')]:
            r=subprocess.run([str(val),'-v',str(DOMAIN),str(problem),str(plan)],capture_output=True,text=True,timeout=3,env=clean_env());(ROOT/'evidence'/f'stage-c-val-{name}.log').write_text(r.stdout+r.stderr);self.assertEqual(validation_outcome(r.returncode,r.stdout+r.stderr),expected);statuses.append({'test':name,'status':r.returncode,'outcome':expected})
        self.assertEqual(validation_outcome(-9,'Plan valid'),'infrastructure');self.assertEqual(validation_outcome(0,'candidate says score 100'),'infrastructure')
        # Plan-found arithmetic precedes VAL; completion after cutoff is not valid even if native VAL accepts.
        self.assertEqual(utility('valid',.201,.2,True),0.)
        RESULTS['validation_and_mapping']={'real_original_PDDL_VAL':statuses,'bogus_candidate_success_cannot_override':True,'ambiguous_search_failures_unscored':True}
    def test_tensor_loading_and_teacher_boundary(self):
        from scorer import fixed_model,validate_tensors,torch,ForbiddenTeacher
        m=fixed_model();state=m.state_dict();p=TMP/'tensor-state.pt';torch.save(state,p)
        validate_tensors(torch.load(p,map_location='cpu',weights_only=True),m)
        for fault in ['keys','shape','dtype','nan']:
            bad=copy.deepcopy(state);key=next(iter(bad))
            if fault=='keys':bad.pop(key)
            elif fault=='shape':bad[key]=bad[key].reshape(-1)
            elif fault=='dtype':bad[key]=bad[key].double()
            else:bad[key].fill_(float('nan'))
            with self.assertRaises(ValueError):validate_tensors(bad,m)
        with self.assertRaises(RuntimeError):ForbiddenTeacher()()
        self.assertIn("False,True",(ROOT/'common.py').read_text())
        RESULTS['tensor_loader']={'weights_only_real_round_trip':True,'keys_shapes_dtypes_finite_checked':True,'raising_teacher_sentinel':True,'trained_model_reuse_disabled':True}
    def test_plan_in_time_but_validator_late(self):
        import evaluator
        worker=TMP/'fixture-worker.py';worker.write_text("import socket,sys,json;fd=int(sys.argv[sys.argv.index('--fd')+1]);s=socket.socket(fileno=fd);s.sendall(b'{\"kind\":\"READY\"}\\n');s.recv(3);s.sendall((json.dumps({'kind':'RESULT','plan':['(turnleftwhenup r)'],'statuses':[]})+'\\n').encode());s.close()")
        validator=TMP/'fixture-validator';validator.write_text('#!/bin/sh\nsleep 0.3\necho "Plan valid"\n');validator.chmod(0o755)
        original_popen=subprocess.Popen
        def launch(command,*a,**kw):
            if str(ROOT/'worker.py') in command:
                command=list(command);command[command.index(str(ROOT/'worker.py'))]=str(worker)
            return original_popen(command,*a,**kw)
        case=json.loads((ROOT/'manifests/development.json').read_text())[0]
        # A test-only sub-second deadline reaches the exact production timing/validation branch.
        with patch('evaluator.subprocess.Popen',launch),patch('evaluator.VAL',validator):
            # Temporarily replace policy constants in a function copy; no production policy change.
            import types
            code=evaluator.case_evaluate.__code__;constants=tuple(.15 if x in (20.,40.) and type(x) is float else x for x in code.co_consts)
            fn=types.FunctionType(code.replace(co_consts=constants),evaluator.case_evaluate.__globals__)
            row=fn(case,ROOT.parent/'stage_b_20261004T230932Z/runs/callback-01/model/final_seed0_Mazenamo.pt',TMP/'late-case','test','reference-bce')
        self.assertEqual(row['outcome'],'deadline');self.assertEqual(row['utility'],0.);self.assertIsNotNone(row['plan_receipt_monotonic']);self.assertTrue(row['cleanup']['ok'])
        RESULTS['late_validation']={'actual_supervisor_plan_before_cutoff_validator_terminated':True,'utility':row['utility'],'outcome':row['outcome']}
    def test_fixed_roster_cli_rejects_case_selection(self):
        from cli import guarded_evaluation
        with self.assertRaisesRegex(ValueError,'forbids case selection'):
            guarded_evaluation('unused',TMP/'unused','test','fixture',mode='fixed',cases=['chosen-case'])
        r=subprocess.run([str(PYTHON),str(ROOT/'cli.py'),'evaluate_internal','--mode','fixed','--case','chosen-case'],cwd=CHECKOUT,env=clean_env(),capture_output=True,text=True,timeout=3)
        self.assertNotEqual(r.returncode,0);self.assertIn('development-only',r.stderr)
        r=subprocess.run([str(PYTHON),str(ROOT/'cli.py'),'evaluate_fixed','--case','chosen-case'],cwd=CHECKOUT,env=clean_env(),capture_output=True,text=True,timeout=3)
        self.assertNotEqual(r.returncode,0);self.assertIn('development-only',r.stderr)
        RESULTS['fixed_roster_boundary']={'fixed_and_internal_fixed_selectors_rejected_by_actual_entry_points':True}
    def test_protected_checks(self):
        from contract import verify_protected
        # Test actual implementation using a fixture definition; never modify protected prior-stage assets.
        target=TMP/'protected';target.write_text('original');definition={'files':[{'path':str(target),'sha256':sha(target)}],'external':[],'links':[]}
        from unittest.mock import mock_open
        original_read=Path.read_text
        def reads(path,*a,**kw):
            if path==ROOT/'protected-assets.json':return json.dumps(definition)
            if path==ROOT/'protocol.json':return json.dumps({'protocol_id':PROTOCOL})
            return original_read(path,*a,**kw)
        with patch.object(Path,'read_text',reads):
            verify_protected();target.write_text('modified')
            with self.assertRaises(ValueError):verify_protected()
        RESULTS['protected_assets']={'changed_task_file_detected_by_actual_check':True,'limitation':'Hashes and Python guards are not a comprehensive sandbox.'}
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests));RESULTS.update(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,seconds=time.monotonic()-START)
    (ROOT/'evidence/stage-c-tests.json').write_text(json.dumps(RESULTS,indent=2)+'\n');shutil.rmtree(TMP);sys.exit(0 if result.wasSuccessful() else 1)
