"""Standard-library tests; all faults are test fixtures, not candidate losses."""
import copy, shutil, time, unittest
from common import *
from unittest.mock import patch
from torch import nn
START=time.perf_counter(); EVIDENCE={}

def assert_nested(a,b):
    if isinstance(a,torch.Tensor): assert torch.equal(a,b),(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a: assert_nested(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b): assert_nested(x,y)
    else: assert a==b,(a,b)

def audited(callback,logits,targets,graph,**kw):
    before=copy.deepcopy((logits.detach(),targets.detach(),{k:v.detach() if v is not None else None for k,v in graph.items()}))
    versions=[v._version for v in [logits,targets]+[v for v in graph.values() if isinstance(v,torch.Tensor)]]
    result=callback(logits,targets,graph,**kw)
    assert_nested(before,(logits.detach(),targets.detach(),{k:v.detach() if v is not None else None for k,v in graph.items()}))
    assert versions==[v._version for v in [logits,targets]+[v for v in graph.values() if isinstance(v,torch.Tensor)]]
    return result

class Tiny(nn.Module):
    def __init__(self): super().__init__(); self.w=nn.Parameter(torch.tensor(0.2))
    def forward(self,g): return [{'nodes':g['nodes']*self.w,'globals':self.w.view(1)}]
def tiny_batch(): return {'graph_input':{'nodes':torch.tensor([[1.],[-2.]]),'globals':None},'graph_target':{'nodes':torch.tensor([[1.],[0.]]),'globals':None}}
def tiny_train(callback=None,criterion=None,epochs=1,observer=None):
    model=Tiny(); opt=torch.optim.Adam(model.parameters(),lr=1e-3)
    out=Path(tempfile.mkdtemp(dir=TMP))
    return gnn_utils.train_model(model,{'train':[tiny_batch(),tiny_batch()],'val':[tiny_batch()]},
        nn.BCEWithLogitsLoss(pos_weight=torch.tensor([10.])) if criterion is None else criterion,
        opt,False,num_epochs=epochs,print_iter=2,save_folder=str(out),compute_loss=callback,batch_observer=observer)
class Tests(unittest.TestCase):
    def test_synthetic(self):
        records=[]
        cases=[([0.],[1.]),([0.],[0.]),([-2.,0.3,4.,-8.],[0.,1.,0.,1.]),
               ([1.,2.,-3.],[1.,1.,1.]),([1.,2.,-3.],[0.,0.,0.]),
               ([-1000.,1000.,-100.,100.],[1.,0.,0.,1.])]
        for dtype in [torch.float32,torch.float64]:
            for x,y in cases:
                a=torch.tensor(x,dtype=dtype).reshape(-1,1).requires_grad_(); b=a.detach().clone().requires_grad_()
                t=torch.tensor(y,dtype=dtype).reshape(-1,1)
                # Unequal graph counts: one node in first graph, remainder in second.
                graph={'nodes':torch.zeros((len(x),2),dtype=dtype),'edges':None,'senders':None,'receivers':None,
                       'n_node':torch.tensor([[1],[len(x)-1]]) if len(x)>1 else torch.tensor([[1]]),'n_edge':None,'globals':None}
                l=nn.BCEWithLogitsLoss(pos_weight=a.new_tensor([10.]))(a,t)
                r=audited(compute_loss,b,t,graph,epoch=0,step=0)
                self.assertTrue(torch.equal(l,r)); ga=torch.autograd.grad(l,a)[0]; gb=torch.autograd.grad(r,b)[0]
                self.assertTrue(torch.equal(ga,gb)); self.assertEqual(r.ndim,0); self.assertEqual(r.dtype,dtype); self.assertEqual(r.device,a.device)
                records.append({'dtype':str(dtype),'logits':x,'targets':y,'value_equal':True,'gradient_equal':True,'loss':l.item()})
        EVIDENCE['synthetic']=records
    def test_real_adam(self):
        g=guider(); train,_=graphs(g); batch=graph_batch_collate([train[i] for i in range(16)])
        models=[]; opts=[]; results=[]
        for i in range(2):
            torch.manual_seed(0); m=setup_graph_net(train,use_gpu=False,num_steps=3); models.append(m); opts.append(torch.optim.Adam(m.parameters(),lr=1e-3))
        self.assertIsNot(models[0],models[1]); assert_nested(models[0].state_dict(),models[1].state_dict()); assert_nested(opts[0].state_dict(),opts[1].state_dict())
        rng=torch.get_rng_state().clone()
        for i,(m,opt) in enumerate(zip(models,opts)):
            torch.set_rng_state(rng); local=copy.deepcopy(batch); targets=local['graph_target']['nodes'].detach()
            opt.zero_grad(); logits=m(local['graph_input'].copy())[-1]['nodes']
            if i==0: loss=nn.BCEWithLogitsLoss(pos_weight=torch.ones([1])*10)(logits,targets)
            else: loss=audited(compute_loss,logits,targets,local['graph_input'],epoch=0,step=0)
            loss.backward(); grads={k:p.grad.detach().clone() for k,p in m.named_parameters()}; opt.step()
            results.append((logits.detach().clone(),loss.detach().clone(),grads,copy.deepcopy(m.state_dict()),copy.deepcopy(opt.state_dict())))
        assert_nested(results[0],results[1])
        labels=json.loads((A/'artifacts/full/successful-labels.json').read_text())['training'][:16]
        EVIDENCE['real_adam']={'initial_equal':True,'independent_models':True,'forward_equal':True,'loss_equal':True,
           'all_parameter_gradients_equal':True,'updated_parameters_and_buffers_equal':True,'optimizer_states_equal':True,
           'loss':results[0][1].item(),'instances':labels,'feature_schema':schema(g),
           'graph_shapes':{k:list(v.shape) if v is not None else None for k,v in batch['graph_input'].items()},
           'n_node':batch['graph_input']['n_node'].tolist(),'input_digest':tensor_digest(batch['graph_input'])}
    def test_guards_and_faults(self):
        fixtures={'non_scalar':lambda *a,**kw: a[0].sum().repeat(2),
                  'nan':lambda *a,**kw: a[0].sum()*float('nan'),
                  'inf':lambda *a,**kw: a[0].sum()*float('inf'),
                  'detached':lambda *a,**kw:compute_loss(*a,**kw).detach()}
        for name,fixture in fixtures.items():
            with self.assertRaises(ValueError): tiny_train(fixture)
        logits=torch.tensor([[2.],[-1.]],requires_grad=True); targets=torch.tensor([[1.],[0.]])
        def inplace(l,t,g,**kw): t.add_(1); return compute_loss(l,t,g,**kw)
        with self.assertRaises(AssertionError): audited(inplace,logits,targets.clone(),{'nodes':logits.detach().clone(),'globals':None},epoch=0,step=0)
        l=compute_loss(logits,targets,{},epoch=0,step=0); double=2*compute_loss(logits,targets,{},epoch=0,step=0)
        self.assertFalse(torch.equal(l,double)); self.assertFalse(torch.equal(torch.autograd.grad(l,logits)[0],torch.autograd.grad(double,logits)[0]))
        # Double BCE satisfies general scalar API: one tiny training run verifies this.
        tiny_train(lambda *a,**kw:2*compute_loss(*a,**kw))
        EVIDENCE['negative']={'runtime_guard_detected':['non_scalar','nan','inf','detached'],
          'test_audit_detected':['in_place_input_mutation','double_BCE_value_and_gradient_inequality'],
          'double_BCE_general_scalar_API_valid':True}
    def test_dispatch_and_steps(self):
        calls=[]; obs=[]
        def cb(l,t,g,*,epoch,step): calls.append((epoch,step)); return compute_loss(l,t,g,epoch=epoch,step=step)
        def forbidden(*a): raise AssertionError('Criterion called with callback')
        tiny_train(cb,forbidden,3,lambda phase,epoch,step,*a:obs.append((phase,epoch,step)))
        self.assertEqual(obs,[('train',0,0),('train',0,1),('val',0,2),('train',1,2),('train',1,3),('train',2,4),('train',2,5),('val',2,6)])
        self.assertEqual(calls,[(e,s) for p,e,s in obs])
        upstream=[]
        def criterion(l,t): upstream.append(1); return nn.functional.binary_cross_entropy_with_logits(l,t,pos_weight=l.new_tensor([10.]))
        tiny_train(None,criterion); self.assertEqual(len(upstream),3)
        EVIDENCE['dispatch']={'callback_invoked':True,'criterion_excluded_when_callback_present':True,'original_path_works':True,'observer_trace':obs}
    def test_cache_and_collision(self):
        with patch('common.pickle.load') as load:
            with self.assertRaises(ValueError): checked_cache(CACHE,'0'*64)
            with self.assertRaises(FileNotFoundError): checked_cache(ROOT/'data/missing.pkl')
            load.assert_not_called()
        p=reserve(TMP/'collision'); (p/'model.pt').write_bytes(b'preserved')
        with self.assertRaises(FileExistsError): reserve(p)
        self.assertEqual((p/'model.pt').read_bytes(),b'preserved')
        EVIDENCE['isolation']={'bad_hash_fails_before_pickle_and_training':True,'missing_cache_fails_before_training':True,'output_collision_rejected_existing_model_preserved':True}
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    EVIDENCE.update(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,elapsed_seconds=time.perf_counter()-START)
    dump(ROOT/'evidence/tests.json',EVIDENCE); shutil.rmtree(TMP)
    sys.exit(0 if result.wasSuccessful() else 1)
