"""Stateless positive-weight-10 BCE, with the source mean over nodes."""
import torch.nn.functional as F


def compute_loss(logits, targets, graph, *, epoch, step):
    return F.binary_cross_entropy_with_logits(
        logits, targets.to(dtype=logits.dtype),
        pos_weight=logits.new_tensor([10.0]), reduction='mean')
